use prueba;
db.items.insert({nombre:'Fideos', categoria: 'Harina', stock: 20});
db.items.insert({nombre:'Leche', categoria: 'Lácteos', stock: 30});
db.items.insert({nombre:'Crema', categoria: 'Lácteos', stock: 15});

db.items.find();

show databases;

show collections;

db.items.find();